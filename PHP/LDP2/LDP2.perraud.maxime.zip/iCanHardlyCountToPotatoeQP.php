<?php

for ($i=0; $i <= intval($_GET['data']); $i++) { 
    echo $i.'<br>';
}

?>