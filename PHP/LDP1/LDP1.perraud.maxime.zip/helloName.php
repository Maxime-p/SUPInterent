<?php
$name = "Pikatchu";
echo "Hello ".$name;
?>